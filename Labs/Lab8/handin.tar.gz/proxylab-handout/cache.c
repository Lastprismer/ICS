#include "cache.h"

cache_line cache[10];

/*
 * init_cache - 初始化cache
 */
/* $begin init_cache */
void init_cache() {
  for (int i = 0; i < CACHE_SIZE; i++) {
    cache[i].valid = 0;
    cache[i].last_usage = 0;
    Sem_init(&cache[i].mutex, 0, 1);
    Sem_init(&cache[i].w, 0, 1);
  }
}
/* $end init_cache */

/*
 * read&write - 读优先的read,write时信号量处理
 */
/* $begin read&write */
void pre_read(cache_line *line) {
  P(&(line->mutex));
  line->readcnt++;
  if (line->readcnt == 1)
    /* First in */
    P(&(line->w));
  V(&(line->mutex));
}
void post_read(cache_line *line) {
  P(&(line->mutex));
  line->readcnt--;
  if (line->readcnt == 0)
    /* Last out */
    V(&(line->w));
  V(&(line->mutex));
}
void pre_write(cache_line *line) { P(&(line->w)); }
void post_write(cache_line *line) { V(&(line->w)); }

/* $end read&write */

/*
 * update_cache - 更新last_usage,line为归零,其他历史++
 */
/* $begin update_cache */
void update_cache(cache_line *line) {
  for (int i = 0; i < CACHE_SIZE; i++) {
    cache_line *tmp = cache + i;
    pre_write(tmp);
    if (tmp == line)
      tmp->last_usage = 0;
    else if (tmp->valid)
      tmp->last_usage++;
    post_write(tmp);
  }
}
/* $end update_cache */

/*
 * find_cache - 查询cache
 * 返回值: 成功则为指针,失败为NULL
 */
/* $begin find_cache */
cache_line *find_cache(char *uri) {
  for (int i = 0; i < CACHE_SIZE; i++) {
    cache_line *tmp = cache + i;
    pre_read(tmp);
    if (tmp->valid && strcmp(tmp->tag, uri) == 0) {
      post_read(tmp);
      return tmp;
    }
    post_read(tmp);
  }
  return NULL;
}
/* $end find_cache */

/*
 * evict_cache - LRU策略驱逐cache行
 */
/* $begin evict_cache */
cache_line *evict_cache() {
  cache_line *ptr = cache;
  int history = -1;
  for (int i = 0; i < CACHE_SIZE; i++) {
    cache_line *tmp = cache + i;
    pre_read(tmp);
    if (!tmp->valid) {
      post_read(tmp);
      return tmp;
    }
    if (tmp->last_usage > history) {
      history = tmp->last_usage;
      ptr = tmp;
    }
    post_read(tmp);
  }
  return ptr;
}
/* $end evict_cache */

/*
 * operate_cache - 匹配失败时操作cache
 */
/* $begin operate_cache */
void operate_cache(char *uri, char *content) {
  cache_line *ptr = evict_cache();
  pre_write(ptr);
  strcpy(ptr->tag, uri);
  memcpy(ptr->block, content, MAX_OBJECT_SIZE);
  ptr->valid = 1;
  post_write(ptr);
  update_cache(ptr);
}