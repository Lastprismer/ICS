#include "cache.h"
#include "csapp.h"
#include "tiny/csapp.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400

/* You won't lose style points for including this long line in your code */
static const char *user_agent_hdr =
    "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 "
    "Firefox/10.0.3\r\n";
static const char *connection_hdr = "Connection: close\r\n";
static const char *proxy_connection_hdr = "Proxy-Connection: close\r\n";

/* 结构体定义 */
typedef struct uri {
  char host[MAXLINE];
  char port[MAXLINE];
  char path[MAXLINE];
} uri_t;

/* 函数定义 */
void sigchld_handler(int sig); // SIGCHLD处理函数
void doit(int fd);
void build_hdr(char *header, uri_t *uri, rio_t *client_rio);
int parse_uri(char *uri, uri_t *uri_addr);
void get_filetype(char *filename, char *filetype);
void clienterror(int fd, char *cause, char *errnum, char *shortmsg,
                 char *longmsg);
void *thread(void *arg);

int main(int argc, char **argv) {
  /* 信号处理函数 */
  signal(SIGPIPE, SIG_IGN);
  signal(SIGCHLD, sigchld_handler);

  int listenfd, *connfd;
  socklen_t clientlen;
  char hostname[MAXLINE], port[MAXLINE];
  struct sockaddr_storage clientaddr;
  pthread_t tid;

  /* 检查命令行参数(端口) */
  if (argc != 2) {
    fprintf(stderr, "usage: %s <port>\n", argv[0]);
    exit(1);
  }
  init_cache();
  /* 监听描述符 */
  listenfd = Open_listenfd(argv[1]);
  while (1) {
    clientlen = sizeof(clientaddr);
    connfd = (int *)Malloc(sizeof(int));
    *connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);
    Getnameinfo((SA *)&clientaddr, clientlen, hostname, MAXLINE, port, MAXLINE,
                0);
    printf("main: Accepted connection from (%s, %s)\n", hostname, port);
    Pthread_create(&tid, NULL, thread, connfd);
    /* 执行 */
  }
  Close(listenfd);
  return 0;
}

/*
 * sigchld_handler - SIGCHLD信号处理函数
 * 功能: 回收所有子进程
 */
/* $begin sigchld_handler */
void sigchld_handler(int sig) {
  int orig_errno = errno;
  while (waitpid(-1, NULL, WNOHANG) > 0)
    ;
  errno = orig_errno;
}

/*
 * thread - 线程
 */
/* $begin thread */
void *thread(void *arg) {
  int connfd = *((int *)arg);
  Pthread_detach(pthread_self());
  Free(arg);
  doit(connfd);
  Close(connfd);
  return NULL;
}

/*
 * doit - 处理一个HTTP事务
 */
/* $begin doit */
void doit(int fd) {
  char buf[MAXLINE], method[MAXLINE], uri[MAXLINE], uuri[MAXLINE],
      version[MAXLINE], cache_block[MAX_OBJECT_SIZE];
  char req_server_hdr[MAXLINE];
  int server_fd;
  rio_t rio, server_rio;
  ssize_t len, obj_size;
  cache_line *cache_ptr;

  Rio_readinitb(&rio, fd);

  /* 读请求行 */
  Rio_readlineb(&rio, buf, MAXLINE);
  // printf("%s", buf);

  /* 解析请求行 */
  sscanf(buf, "%s %s %s", method, uri, version);

  /* 是否是GET方法 */
  if (strcasecmp(method, "GET") != 0) {
    clienterror(fd, method, "501", "Not Implemented",
                "Tiny does not implement this method");
    return;
  }

  /* cache */
  cache_ptr = find_cache(uri);
  if (cache_ptr) {
    pre_read(cache_ptr);
    Rio_writen(fd, cache_ptr->block, MAX_OBJECT_SIZE);
    post_read(cache_ptr);
    update_cache(cache_ptr);
    return;
  }

  uri_t *uri_struct = (uri_t *)Malloc(sizeof(uri_t));
  strcpy(uuri, uri);
  if (parse_uri(uri, uri_struct) == 1) {
    printf("Error: (prase_uri) invalid uri\n");
    return;
  }
  build_hdr(req_server_hdr, uri_struct, &rio);

  /* 链接服务器 */
  server_fd = Open_clientfd(uri_struct->host, uri_struct->port);

  // 转发给服务器
  Rio_readinitb(&server_rio, server_fd);
  Rio_writen(server_fd, req_server_hdr, strlen(req_server_hdr));

  // 回复给客户端
  obj_size = 0;
  while ((len = Rio_readlineb(&server_rio, buf, MAXLINE)) != 0) {
    obj_size += len;
    if (obj_size < MAX_OBJECT_SIZE) {
      // 调了半天,有几个real page是塞不进cache里的
      memcpy(cache_block + obj_size - len, buf, len);
    }
    Rio_writen(fd, buf, len);
  }

  // cache操作
  operate_cache(uuri, cache_block);

  // 关闭服务器描述符
  Close(server_fd);
  Free(uri_struct);
}
/* $end doit */

/*
 * build_hdr - 创建响应报头,结合已有信息与读入的报头
 *             忽略
 */
/* $begin build_hdr */
void build_hdr(char *header, uri_t *uri, rio_t *client_rio) {
  char buf[MAXLINE], request_header[MAXLINE];

  sprintf(request_header, "GET %s HTTP/1.0\r\nHost: %s:%s\r\n%s%s%s", uri->path,
          uri->host, uri->port, user_agent_hdr, connection_hdr,
          proxy_connection_hdr);
  printf("\nbuild_hdr: check headers\n");
  while (Rio_readlineb(client_rio, buf, MAXLINE)) {
    if (strcmp(buf, "\r\n") == 0)
      break;
    printf("buf -> %s", buf);
    if (strncasecmp(buf, "Host:", 5) == 0 ||
        strncasecmp(buf, "User-Agent:", 12) == 0 ||
        strncasecmp(buf, "Connection:", 11) == 0 ||
        strncasecmp(buf, "Proxy-Connection:", 17) == 0)
      continue;
    sprintf(request_header, "%s%s", request_header, buf);
  }
  sprintf(header, "%s%s", request_header, "\r\n");
  return;
}

/* $end read_requesthdrs */

/*
 * parse_uri - 将uri解析为主机名、端口和路径
 *             解析成功返回0,否则返回1
 */
/* $begin parse_uri */
int parse_uri(char *uri, uri_t *uri_addr) {
  /*
    http_URL       = "http:" "//" host [ ":" port ] [ abs_path ]

          host           = <A legal Internet host domain name
                            or IP address (in dotted-decimal form),
                            as defined by Section 2.1 of RFC 1123>

          port           = *DIGIT

  If the port is empty or not given, port 80 is assumed.
  Replacing an empty abs_path with "/".
  */

  // http://www.cmu.edu:8080/hub/index.html
  char *valid_host = strstr(uri, "//");
  // //www.cmu.edu:8080/hub/index.html

  if (valid_host == NULL) {
    return 1;
  }
  char *valid_port = strstr(valid_host + 2, ":");
  // :8080/hub/index.html
  if (valid_port != NULL) {
    int tmp;
    if (sscanf(valid_port, ":%d%s", &tmp, uri_addr->path) < 2)
      return 1;
    sprintf(uri_addr->port, "%d", tmp);
    *valid_port = '\0';
  } else {
    // 默认端口为80
    strcpy(uri_addr->port, "80");
    char *path = strstr(valid_host + 2, "/");
    // /hub/index.html
    if (path == NULL) {
      return 1;
    }
    strcpy(uri_addr->path, path);
    *path = '\0';
  }
  strcpy(uri_addr->host, valid_host + 2);
  return 0;
}

/* $end parse_uri */

/*
 * get_filetype - derive file type from file name
 */
void get_filetype(char *filename, char *filetype) {
  if (strstr(filename, ".html"))
    strcpy(filetype, "text/html");
  else if (strstr(filename, ".gif"))
    strcpy(filetype, "image/gif");
  else if (strstr(filename, ".png"))
    strcpy(filetype, "image/png");
  else if (strstr(filename, ".jpg"))
    strcpy(filetype, "image/jpeg");
  else if (strstr(filename, ".css"))
    strcpy(filetype, "text/css");
  else if (strstr(filename, ".js"))
    strcpy(filetype, "application/javascript");
  else
    strcpy(filetype, "text/plain");
}
/*
 * clienterror - returns an error message to the client
 */
/* $begin clienterror */
void clienterror(int fd, char *cause, char *errnum, char *shortmsg,
                 char *longmsg) {
  char buf[MAXLINE], body[MAXBUF];

  // #pragma GCC diagnostic push
  // #pragma GCC diagnostic ignored "-Wformat-overflow"
  /* Build the HTTP response body */
  sprintf(body, "<html><title>Tiny Error</title>");
  sprintf(body,
          "%s<body bgcolor="
          "ffffff"
          ">\r\n",
          body);
  sprintf(body, "%s%s: %s\r\n", body, errnum, shortmsg);
  sprintf(body, "%s<p>%s: %s\r\n", body, longmsg, cause);
  sprintf(body, "%s<hr><em>The Tiny Web server</em>\r\n", body);
  // #pragma GCC diagnostic pop

  /* Print the HTTP response */
  sprintf(buf, "HTTP/1.0 %s %s\r\n", errnum, shortmsg);
  rio_writen(fd, buf, strlen(buf));
  sprintf(buf, "Content-type: text/html\r\n");
  rio_writen(fd, buf, strlen(buf));
  sprintf(buf, "Content-length: %d\r\n\r\n", (int)strlen(body));
  rio_writen(fd, buf, strlen(buf));
  rio_writen(fd, body, strlen(body));
}
/* $end clienterror */
