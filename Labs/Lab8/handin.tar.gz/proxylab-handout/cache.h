#include "csapp.h"
#include "tiny/csapp.h"
#include <stdio.h>
#include <stdlib.h>
#include <strings.h>

/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400
#define CACHE_SIZE 10

typedef struct {
  char block[MAX_OBJECT_SIZE];
  char tag[MAXLINE];
  char valid;
  int last_usage;
  int readcnt;
  sem_t w;
  sem_t mutex;
} cache_line;

void init_cache();
void pre_read(cache_line *line);
void post_read(cache_line *line);
void pre_write(cache_line *line);
void post_write(cache_line *line);

void update_cache(cache_line *line);
cache_line *find_cache(char *uri);
cache_line *evict_cache();
void operate_cache(char *uri, char *content);