/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_283(unsigned x)
{
    return x + 3281082457U;
}

unsigned getval_464()
{
    return 3281031256U;
}

void setval_110(unsigned *p)
{
    *p = 3284650312U;
}

void setval_214(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_235()
{
    return 3281031256U;
}

unsigned addval_499(unsigned x)
{
    return x + 2425393224U;
}

unsigned getval_174()
{
    return 3284633672U;
}

void setval_489(unsigned *p)
{
    *p = 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_452()
{
    return 2425667977U;
}

unsigned addval_277(unsigned x)
{
    return x + 3224947209U;
}

unsigned addval_453(unsigned x)
{
    return x + 3380926089U;
}

unsigned getval_355()
{
    return 3285614955U;
}

unsigned getval_168()
{
    return 3285616969U;
}

unsigned addval_236(unsigned x)
{
    return x + 3247494793U;
}

unsigned getval_458()
{
    return 2425408137U;
}

unsigned getval_370()
{
    return 3675835017U;
}

unsigned addval_315(unsigned x)
{
    return x + 2425408169U;
}

unsigned getval_220()
{
    return 583256729U;
}

void setval_461(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_246(unsigned x)
{
    return x + 3523791497U;
}

unsigned getval_255()
{
    return 3375945352U;
}

unsigned getval_279()
{
    return 3523789192U;
}

void setval_158(unsigned *p)
{
    *p = 3380923081U;
}

unsigned getval_322()
{
    return 3223896457U;
}

unsigned addval_156(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_423(unsigned x)
{
    return x + 3381974665U;
}

void setval_395(unsigned *p)
{
    *p = 2445379853U;
}

void setval_443(unsigned *p)
{
    *p = 3680551305U;
}

void setval_154(unsigned *p)
{
    *p = 3353381192U;
}

unsigned getval_428()
{
    return 3380139657U;
}

void setval_310(unsigned *p)
{
    *p = 3353381192U;
}

void setval_479(unsigned *p)
{
    *p = 2497743176U;
}

void setval_346(unsigned *p)
{
    *p = 3269495112U;
}

unsigned getval_386()
{
    return 3227568777U;
}

unsigned addval_311(unsigned x)
{
    return x + 3352725982U;
}

void setval_351(unsigned *p)
{
    *p = 3238652340U;
}

unsigned getval_312()
{
    return 3286272332U;
}

unsigned getval_191()
{
    return 3281043849U;
}

void setval_247(unsigned *p)
{
    *p = 3525362057U;
}

unsigned addval_347(unsigned x)
{
    return x + 3269495112U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
